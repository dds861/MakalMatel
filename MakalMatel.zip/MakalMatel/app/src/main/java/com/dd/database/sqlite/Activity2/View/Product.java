package com.dd.database.sqlite.Activity2.View;

public class Product {
    public Product(String text1) {
        this.text1 = text1;
    }

    String text1;

    public String getText1() {
        return text1;
    }

    public void setText1(String text1) {
        this.text1 = text1;
    }
}
