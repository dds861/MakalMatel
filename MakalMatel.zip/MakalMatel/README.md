You may read readme from medium.com 
https://medium.com/@dds861/sqlite-load-db-file-and-read-it-8960680e1ad8
