package com.dd.database.sqlite.Activity1.Model;

import java.util.List;

public interface IModel {

    List<String> getListFromDatabase();
}
