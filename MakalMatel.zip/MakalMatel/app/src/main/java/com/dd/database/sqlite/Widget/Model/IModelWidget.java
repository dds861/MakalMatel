package com.dd.database.sqlite.Widget.Model;

import java.util.List;

public interface IModelWidget {


    //метод возвращает случайный макалМател
    String getRandomMakalFromDatabase();

}
