package com.dd.database.sqlite.Widget.Presenter;

public interface IPresenterWidget {

    String getRandomMakalFromDatabase();
}
