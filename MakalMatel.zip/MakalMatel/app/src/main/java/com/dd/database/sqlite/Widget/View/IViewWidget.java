package com.dd.database.sqlite.Widget.View;

public interface IViewWidget {
}
